#pragma once
#include "Object2D.h"


class Enemy: public Object2D
{

public:

	Enemy(Point2D p, Color _color, bool _fill);
	/*
	Functie care determina daca s-a produs o coliziune intre inamic si glont sau naveta; 
	poate fi aplelata pentru orcare doua obiecte din plan.
	*/
	virtual bool collision(Object2D*) = 0;

	Enemy() {};


};