#pragma once
#include "Object2D.h"

//using namespace std;

class Ship: public Object2D
{

public:
	/*Ship()
	{
		color.r = color.b = color.g = 0;
		fill = false;
		type = 4;
	}
	*/
	Ship(Point2D p,  float _radius, Color _color, bool _fill){
		fill = _fill;
		color.r = _color.r;
		color.g = _color.g;
		color.b = _color.b;
		type = 2;

		float u;
		float du = 10;
		float u_rad;
		for (u = 0; u <= 360; u+=du)
		{
			Point2D *p1 = new Point2D();
			u_rad = u * 3.14159 / 180;
			p1->x = (p.x-20) + _radius * cos(u_rad);
			p1->y = (p.y-5) + _radius * sin(u_rad);
		

			points.push_back(p1);
			transf_points.push_back(new Point2D(p1->x,p1->y));
		}

		points.push_back(new Point2D(p.x,p.y));
		transf_points.push_back(new Point2D(p.x,p.y));

		Point2D *p2 = new Point2D(); p2->x = p.x - 25;  p2->y = p.y + 12;
		points.push_back(p2);
		transf_points.push_back(new Point2D(p2->x,p2->y));

		Point2D *p3 = new Point2D(); p3->x = p.x - 40; p3->y = p.y - 10;
		points.push_back(p3);
		transf_points.push_back(new Point2D(p3->x,p3->y));

		Point2D *p4 = new Point2D(); p4->x = p.x - 22; p4->y = p.y - 25;
		points.push_back(p4);
		transf_points.push_back(new Point2D(p4->x,p4->y));

		Point2D *p5 = new Point2D(); p5->x = p.x; p5->y = p.y - 10;
		points.push_back(p5);
		transf_points.push_back(new Point2D(p5->x,p5->y));

		Point2D *p6 = new Point2D(); p6->x = p.x - 20; p6->y = p.y - 20;
		points.push_back(p6);
		transf_points.push_back(new Point2D(p6->x,p6->y));

		Point2D *p7 = new Point2D(); p7->x = p.x - 32; p7->y = p.y - 7;
		points.push_back(p7);
		transf_points.push_back(new Point2D(p7->x,p7->y));

		Point2D *p8 = new Point2D(); p8->x = p.x - 20; p8->y = p.y + 6.5;
		points.push_back(p8);
		transf_points.push_back(new Point2D(p8->x,p8->y));


	}

	Ship(Point2D p, float _radius,  Point2D _center, Color _color, bool _fill){
		fill = _fill;
		color.r = _color.r;
		color.g = _color.g;
		color.b = _color.b;
		type = 2;
		center = _center;
		radius = _radius;

		float u;
		float du = 10;
		float u_rad;
		for (u = 0; u <= 360; u+=du)
		{
			Point2D *p1 = new Point2D();
			u_rad = u * 3.14159 / 180;
			p1->x = (p.x-20) + _radius * cos(u_rad);
			p1->y = (p.y-5) + _radius * sin(u_rad);
		

			points.push_back(p1);
			transf_points.push_back(new Point2D(p1->x,p1->y));
		}

		//collision_points.push_back(new Point2D(p.x-20,p.y-5));
		
		points.push_back(new Point2D(p.x,p.y));
		transf_points.push_back(new Point2D(p.x,p.y));

		Point2D *p2 = new Point2D(); p2->x = p.x - 25;  p2->y = p.y + 12;
		points.push_back(p2);
		transf_points.push_back(new Point2D(p2->x,p2->y));

		Point2D *p3 = new Point2D(); p3->x = p.x - 40; p3->y = p.y - 10;
		points.push_back(p3);
		transf_points.push_back(new Point2D(p3->x,p3->y));

		Point2D *p4 = new Point2D(); p4->x = p.x - 22; p4->y = p.y - 25;
		points.push_back(p4);
		transf_points.push_back(new Point2D(p4->x,p4->y));

		Point2D *p5 = new Point2D(); p5->x = p.x; p5->y = p.y - 10;
		points.push_back(p5);
		transf_points.push_back(new Point2D(p5->x,p5->y));

		Point2D *p6 = new Point2D(); p6->x = p.x - 20; p6->y = p.y - 20;
		points.push_back(p6);
		transf_points.push_back(new Point2D(p6->x,p6->y));

		Point2D *p7 = new Point2D(); p7->x = p.x - 32; p7->y = p.y - 7;
		points.push_back(p7);
		transf_points.push_back(new Point2D(p7->x,p7->y));

		Point2D *p8 = new Point2D(); p8->x = p.x - 20; p8->y = p.y + 6.5;
		points.push_back(p8);
		transf_points.push_back(new Point2D(p8->x,p8->y));


	}


	~Ship() {}
	//Functie ce translateaza naveta cu x.
	void Move(float x)
	{
		Transform2D::translateMatrix(x,0);
		Transform2D::applyTransform_o(this);
	}


};