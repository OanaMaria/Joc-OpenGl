#pragma once
#include "Enemy.h"

class Enemy_square_romb: public Enemy
{

public:

	Enemy_square_romb(Point2D p, Point2D _center, float _radius, Color _color, bool _fill){
		fill = _fill;
		color.r = _color.r;
		color.g = _color.g;
		color.b = _color.b;
		type = 4;
		center = _center;
		radius = _radius;
		
		points.push_back(new Point2D(p.x,p.y));
		transf_points.push_back(new Point2D(p.x,p.y));
		
		Point2D *p2 = new Point2D(); p2->x = p.x;  p2->y = p.y - 20;
		points.push_back(p2);
		transf_points.push_back(new Point2D(p2->x,p2->y));

		Point2D *p3 = new Point2D(); p3->x = p.x + 40; p3->y = p.y - 20;
		points.push_back(p3);
		transf_points.push_back(new Point2D(p3->x,p3->y));

		Point2D *p4 = new Point2D(); p4->x = p.x + 40; p4->y = p.y + 20;
		points.push_back(p4);
		transf_points.push_back(new Point2D(p4->x,p4->y));

		Point2D *p5 = new Point2D(); p5->x = p.x; p5->y = p.y + 20;
		points.push_back(p5);
		transf_points.push_back(new Point2D(p5->x,p5->y));

		Point2D *p6 = new Point2D(); p6->x = p.x ; p6->y = p.y;
		points.push_back(p6);
		transf_points.push_back(new Point2D(p6->x,p6->y));

		Point2D *p7 = new Point2D(); p7->x = p.x + 20; p7->y = p.y + 20;
		points.push_back(p7);
		transf_points.push_back(new Point2D(p7->x,p7->y));

		Point2D *p8 = new Point2D(); p8->x = p.x + 40; p8->y = p.y;
		points.push_back(p8);
		transf_points.push_back(new Point2D(p8->x,p8->y));

		Point2D *p9 = new Point2D(); p9->x = p.x + 20; p9->y = p.y - 20;
		points.push_back(p9);
		transf_points.push_back(new Point2D(p9->x,p9->y));
		
	}


	~Enemy_square_romb() {}

	bool collision(Object2D* object){
		
		bool ok = false;
		if (pow(this->center.x - object->center.x, 2) + pow(this->center.y - object->center.y, 2) < pow(this->radius + object->radius, 2))
			ok = true;
		return ok;
	}

};