#include "Framework/DrawingWindow.h"
#include "Framework/Visual2D.h"
#include "Framework/Transform2D.h"
#include "Framework/Line2D.h"
#include "Framework/Rectangle2D.h"
#include "Framework/Circle2D.h"
#include "Framework/Polygon2D.h"
#include "Framework/Ship.h"
#include "Framework/Enemy_2square.h"
#include "Framework/Enemy_square_romb.h"
#include "Framework/Enemy_arrow.h"
#include "Framework/Enemy_L.h"
#include "Framework/Bullet.h"
#include <iostream>
#include <windows.h>


#define PI 3.14159265358979323846

using namespace std;
bool fire = false;
Visual2D *v2d1, *v2d2;
Ship *ship, *ship1;
Enemy_2square* purple_enemy, *yellow_enemy, *olive_enemy;
Enemy_square_romb* green_enemy, *azure_enemy, *darkpink_enemy;
Enemy_arrow *lightpurple_enemy, *pink_enemy, *brickred_enemy;
Enemy_L *blue_enemy, *orange_enemy;
Bullet *bullet;
Circle2D *cerc, *cerc1, *proiectil;
Polygon2D *triunghi;
Text *text, *text1, *text2, *text3;
float x, x1=0, u=0, nr=0, y, lineInclination, y_move = 1;
int score = 0, lives = 1000;
//Functie de transformare a unei variabile float in string
string transform(int i){
	std::string result = std::to_string(i);    

return result;
}

//functia care permite adaugarea de obiecte
void DrawingWindow::init()
{
	v2d1 = new Visual2D(0,0,DrawingWindow::width,DrawingWindow::height/8,0,0,DrawingWindow::width,DrawingWindow::height/8);  
	addVisual2D(v2d1);
	v2d1->tipTran(true);
	

	v2d2 = new Visual2D(0,0,DrawingWindow::width,DrawingWindow::height,0,DrawingWindow::height/8,DrawingWindow::width,DrawingWindow::height);  
	addVisual2D(v2d2);
	v2d2->tipTran(true);
	
	text = new Text("SCOR:",Point2D(30,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(text,v2d1);

	string rezultat = transform(score);
	text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(text1,v2d1);

	string rezultat1 = transform(lives);
	text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(text2,v2d1);

	text3 = new Text("x",Point2D(310,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(text3,v2d1);

	//Crearea navetei
	ship = new Ship(Point2D(120,105), 30, Point2D(100,100), Color(1,0,0), false);
	addObject2D_to_Visual2D(ship,v2d2);
	
	ship1 = new Ship(Point2D(120,105), 30, Color(1,0,0), false);
	Transform2D::scaleMatrix(0.5,0.5);
	Transform2D::translateMatrix(300,-30);
	Transform2D::applyTransform_o(ship1);
	addObject2D_to_Visual2D(ship1,v2d1);
	
	//Crearea armei
	triunghi = new Polygon2D(Color(0,0,0), true);
	triunghi->addPoint(Point2D(220,100));
	triunghi->addPoint(Point2D(145,115));
	triunghi->addPoint(Point2D(145,85));
	addObject2D_to_Visual2D(triunghi,v2d2);

	//Crearea proiectilului
	bullet = new Bullet(Point2D(triunghi->points[0]->x, triunghi->points[0]->y), 5, Color(0, 0, 0), true);
	addObject2D_to_Visual2D(bullet, v2d2);

	//Crearea inamicilor
	purple_enemy = new Enemy_2square(Point2D(300,300), Point2D(317, 285), 20, Color(1,0,1), false);
	addObject2D_to_Visual2D(purple_enemy,v2d2);

	yellow_enemy = new Enemy_2square(Point2D(200,400), Point2D(217,385), 20, Color(1,1,0), false);
	addObject2D_to_Visual2D(yellow_enemy,v2d2);
	
	olive_enemy = new Enemy_2square(Point2D(400,250), Point2D(417,235), 20, Color(0.333333, 0.419608, 0.184314), false);
	addObject2D_to_Visual2D(olive_enemy,v2d2);
	
	green_enemy = new Enemy_square_romb(Point2D(100,300), Point2D(120,290), 20, Color(0,1,0), false);
	addObject2D_to_Visual2D(green_enemy,v2d2);

	azure_enemy = new Enemy_square_romb(Point2D(10,200),  Point2D(30,135), 5, Color(0,1,1), false);
	addObject2D_to_Visual2D(azure_enemy,v2d2);

	darkpink_enemy = new Enemy_square_romb(Point2D(500,300),  Point2D(520,235), 20, Color(0.803922, 0.360784, 0.360784), false);
	addObject2D_to_Visual2D(darkpink_enemy,v2d2);
	
	lightpurple_enemy = new Enemy_arrow(Point2D(200,200), Point2D(220,200), 10, Color( 0.854902, 0.439216, 0.839216), false);
	addObject2D_to_Visual2D(lightpurple_enemy,v2d2);

	pink_enemy = new Enemy_arrow(Point2D(200,300),  Point2D(220,300), 25, Color(0.980392, 0.501961, 0.447059), false);
	addObject2D_to_Visual2D(pink_enemy,v2d2);

	brickred_enemy = new Enemy_arrow(Point2D(60,400),  Point2D(80,400), 25, Color(0.698039, 0.133333, 0.133333), false);
	addObject2D_to_Visual2D(brickred_enemy,v2d2);

	blue_enemy = new Enemy_L(Point2D(400,400),  Point2D(440,385), 20, Color(0,0,1), true);
	addObject2D_to_Visual2D(blue_enemy,v2d2);

	orange_enemy = new Enemy_L(Point2D(600,200),  Point2D(640,185), 20, Color(1, 0.647059, 0), true);
	addObject2D_to_Visual2D(orange_enemy,v2d2);
	
}


//functia care permite animatia
void DrawingWindow::onIdle()
{
	static int iter1 = 0, iter2 = 0, iter3 = 0;
	static float i1 = 0;
	float ty1 = 0, ty2 = 0, ty3 = 0, ty4 = 0, ty6 = 0, tx1 = 0, tx2 = 0, tx3 = 0, tx6 = 0;
	iter1++;
	iter2++;
	iter3++;
	i1 = float((rand() % 200)/100.00) ;
	
	
	
	//Realizarea animatiei pentru fiecare inamic
//-----------------------------------------	
	if (iter1 <= 180){
		ty1 += i1;
		ty3 -= i1;
		tx1 = 0;
		
		purple_enemy->center.y += i1;
		azure_enemy->center.y += i1;
		olive_enemy->center.y -= i1;
		blue_enemy->center.y -= i1;
		brickred_enemy->center.y -= i1;
	
	}
	
	else

		if (iter1 <= 360){		
			ty1 -=  i1;
			ty3 += i1;
			tx1 = 0;
			
			purple_enemy->center.y -= i1;
			azure_enemy->center.y -= i1;
			olive_enemy->center.y += i1;
			blue_enemy->center.y += i1;
			brickred_enemy->center.y += i1;
		}
		else 
			if (iter1 <= 540){		
				ty1 = 0;
				ty3 = 0;
				tx1 += 1;

				
				purple_enemy->center.x += 1;
				azure_enemy->center.x += 1;
				olive_enemy->center.x += 1;
				blue_enemy->center.x += 1;
				brickred_enemy->center.x += 1;
			}else

				if (iter1 <= 720){		
					ty1 = 0;
					ty3 = 0;
					tx1 -= 1;

					
					purple_enemy->center.x -= 1;
					azure_enemy->center.x -= 1;
					olive_enemy->center.x -= 1;
					blue_enemy->center.x -= 1;
					brickred_enemy->center.x -= 1;
				}
				else{
					iter1 = 0;	
		}
//-----------------------------------------
	
	if (iter2 <= 150){
		ty2 += i1;
		tx2 = 0;
		green_enemy->center.y += i1;
		darkpink_enemy->center.y += i1;
	}else

		if (iter2 <= 300){
			ty2 -=  i1;
			tx2 = 0;
			green_enemy->center.y -= i1;
			darkpink_enemy->center.y -= i1;
		}else
			
			if (iter2 <= 450){		
				ty2 = 0;
				tx2 += 1;
				green_enemy->center.x += 1;
				darkpink_enemy->center.x += 1;
		}else

			if (iter2 <= 600){	
				ty2 = 0;
				tx2 -= 1;
				green_enemy->center.x -= i1;
			darkpink_enemy->center.x -= i1;
		}else{
			iter2 = 0;
		}
//-----------------------------------------
	
	if (iter3 <= 50){
		ty4 += i1;
		tx3 = 0;
		
		yellow_enemy->center.y += i1;
		pink_enemy->center.y += i1;
		orange_enemy->center.y += i1;
		lightpurple_enemy->center.y += i1;
	}
	else

		if (iter3 <= 100){		
			ty4 -=  i1;
			tx3 = 0;
			
			yellow_enemy->center.y -= i1;
			pink_enemy->center.y -= i1;
			orange_enemy->center.y -= i1;
			lightpurple_enemy->center.y -= i1;
		}
		else 
			if (iter3 <= 150){		
				ty4 = 0;
				tx3 += 1;
				
				yellow_enemy->center.x += 1;
				pink_enemy->center.x += 1;
				orange_enemy->center.x += 1;
				lightpurple_enemy->center.x += 1;
		}else

		if (iter3 <= 200){		
			ty4 = 0;
			tx3 -= 1;
			yellow_enemy->center.x -= 1;
			pink_enemy->center.x -= 1;
			orange_enemy->center.x -= 1;
			lightpurple_enemy->center.x -= 1;
		}
		else{
			iter3 = 0;	
		}
//-----------------------------------------
		//Testarea coliziunilor dintre naveta si scaderea numarului de vieti
	if (olive_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(olive_enemy);
		}
		
	if (purple_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(purple_enemy);
		}

	if (green_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(green_enemy);
		}

	if (orange_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(orange_enemy);
		}

	if (pink_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(pink_enemy);
		}

	if (darkpink_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(darkpink_enemy);
		}

	if (azure_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(azure_enemy);
		}

	if (blue_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(blue_enemy);
		}
	
	if (brickred_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(brickred_enemy);
		}
	
	if (yellow_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(yellow_enemy);
		}
	
	if (lightpurple_enemy->collision(ship) == true){
		lives--;
		removeText_from_Visual2D(text2, v2d1);
		string rezultat1 = transform(lives);
		text2 = new Text(rezultat1,Point2D(290,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d1);
		
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0,200);
		Transform2D::applyTransform_o(lightpurple_enemy);
		}
	
	//Afisarea mesajului GAME OVER daca numarul de vieti a ajuns la 0
	if(lives == 0){
		removeObject2D_from_Visual2D(olive_enemy, v2d2);
		removeObject2D_from_Visual2D(orange_enemy, v2d2);
		removeObject2D_from_Visual2D(pink_enemy, v2d2);
		removeObject2D_from_Visual2D(darkpink_enemy, v2d2);
		removeObject2D_from_Visual2D(blue_enemy, v2d2);
		removeObject2D_from_Visual2D(brickred_enemy, v2d2);
		removeObject2D_from_Visual2D(azure_enemy, v2d2);
		removeObject2D_from_Visual2D(lightpurple_enemy, v2d2);
		removeObject2D_from_Visual2D(green_enemy, v2d2);
		removeObject2D_from_Visual2D(yellow_enemy, v2d2);
		removeObject2D_from_Visual2D(purple_enemy, v2d2);
		removeObject2D_from_Visual2D(ship, v2d2);

		text2 = new Text("GAME OVER",Point2D(300,300),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d2);
		
	}
	
	//Realizarea translatiei proiectilului pe directia pantei dreptei determinate de centrul navetei si varful armei
	if(fire == true){
		if (bullet->center.x <= 705 && bullet->center.x >= 0 && bullet->center.y <= 500 && bullet->center.y >= 0 || bullet == nullptr){
			tx6 += 10*lineInclination;
			ty6 += 10*y_move;

			bullet->center.x += tx6;
			bullet->center.y += ty6;
			Transform2D::loadIdentityMatrix();
			Transform2D::translateMatrix(tx6,ty6);
			Transform2D::applyTransform_o(bullet);	
			
		}
		else{
			bullet = new Bullet(Point2D(triunghi->transf_points[0]->x, triunghi->transf_points[0]->y), 5, Color(0,0,1), true);
			addObject2D_to_Visual2D(bullet, v2d2);
			fire = false;
		}

	}

	//Verificarea coliziunilor dintre proiectil si inamici si cresterea scorului 
	int nr = 0;
	if (olive_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(olive_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (purple_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(purple_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (green_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(green_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (lightpurple_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(lightpurple_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (blue_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(blue_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (yellow_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(yellow_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (azure_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(azure_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (pink_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(pink_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (brickred_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(brickred_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (orange_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(orange_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	nr = 0;
	if (darkpink_enemy->collision(bullet) == true){
		
		nr++;
		if (nr == 1)
			score += 100;
		
		removeText_from_Visual2D(text1, v2d1);
		string rezultat = transform(score);
		text1 = new Text(rezultat,Point2D(110,10),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		
		addText_to_Visual2D(text1,v2d1);
		removeObject2D_from_Visual2D(darkpink_enemy, v2d2);
		removeObject2D_from_Visual2D(bullet, v2d2);
			}
	
	if(olive_enemy == nullptr && azure_enemy == nullptr && orange_enemy == nullptr && blue_enemy == nullptr && pink_enemy == nullptr && 
		darkpink_enemy == nullptr && brickred_enemy == nullptr && yellow_enemy == nullptr && purple_enemy == nullptr && 
		lightpurple_enemy == nullptr && green_enemy == nullptr){
		text2 = new Text("CONGRATULATIONS!",Point2D(300,300),Color(1,0,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(text2,v2d2);
	}

	//Aplicarea transformarilor specifice prentru fiecare inamic
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx1,ty1);
	Transform2D::applyTransform_o(purple_enemy);
	Transform2D::applyTransform_o(azure_enemy);

	
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx2,ty2);
	Transform2D::applyTransform_o(green_enemy);
	Transform2D::applyTransform_o(darkpink_enemy);
	
	
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx1,ty3);
	Transform2D::applyTransform_o(blue_enemy);
	Transform2D::applyTransform_o(olive_enemy);
	Transform2D::applyTransform_o(brickred_enemy);
	
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx3,ty4);
	Transform2D::applyTransform_o(yellow_enemy);
	Transform2D::applyTransform_o(pink_enemy);
	Transform2D::applyTransform_o(lightpurple_enemy);
	Transform2D::applyTransform_o(orange_enemy);
	
}

//functia care se apeleaza la redimensionarea ferestrei
void DrawingWindow::onReshape(int width,int height)
{
	
	v2d1->poarta(0,0,width,height/8); 
		
	v2d2->poarta(0,height/8,width,height);
}

//functia care defineste ce se intampla cand se apasa pe tastatura
void DrawingWindow::onKey(unsigned char key)
{
	//Deplasare naveta stanga, dreapta si rotire in sus si in jos.
	if (key == KEY_UP){ 
		x = 0; u = 0; x += 5; x1 += 5;
		ship->center.x += 5;
		Transform2D::loadIdentityMatrix();
		ship->Move(x);
		Transform2D::applyTransform_o(triunghi);
		if (fire == false)
			Transform2D::applyTransform_o(bullet);
					}
	if (key == KEY_DOWN){ 
		x = 0; u = 0; x -= 5; x1 -= 5;
		ship->center.x -= 5;
		Transform2D::loadIdentityMatrix();
		ship->Move(x);
		Transform2D::applyTransform_o(triunghi);
		if (fire == false)
			Transform2D::applyTransform_o(bullet);
					}
	if (key == KEY_LEFT){
		u = 0;  x = 0; u +=0.1;

		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(-100 - x1,-100);
		Transform2D::rotateMatrix(u);
		Transform2D::translateMatrix(100 + x1,100);
		Transform2D::applyTransform_o(ship);
		Transform2D::applyTransform_o(triunghi);
		if (fire == false)
			Transform2D::applyTransform_o(bullet);
					}
	if (key == KEY_RIGHT){
		u = 0; x = 0; u -=0.1;

		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(-100 - x1,-100);
		Transform2D::rotateMatrix(u);		
		Transform2D::translateMatrix(100 + x1,100);
		Transform2D::applyTransform_o(ship);
		Transform2D::applyTransform_o(triunghi);
		if (fire == false)
			Transform2D::applyTransform_o(bullet);

					}
	//Incarcarea armei
	if (key == 'l'){
		triunghi->color.r = 1;
		triunghi->color.g = 0;
		triunghi->color.b = 0;
		bullet->color.r = 0;
		bullet->color.g = 0;
		bullet->color.b = 1;
	}
	//Ascunderea armei
	if (key == 'h'){
		triunghi->color.r = 0;
		triunghi->color.g = 0;
		triunghi->color.b = 0;
		bullet->color.r = 0;
		bullet->color.g = 0;
		bullet->color.b = 0;
	}
	//Lansarea proiectilului si calcularea directiei lui de deplasare
	if(key == KEY_SPACE){
		fire = true;
		if (ship->center.y == triunghi->transf_points[0]->y){
			lineInclination = 1;
			y_move = 0;
		}
		else{
			lineInclination = abs((ship->center.x - triunghi->transf_points[0]->x) / (ship->center.y - triunghi->transf_points[0]->y));
			y_move = 1;
			}
	}

	
}
//functia care defineste ce se intampla cand se da click pe mouse
void DrawingWindow::onMouse(int button,int state,int x, int y)
{
	
}


int main(int argc, char** argv)
{
	//creare fereastra
	DrawingWindow dw(argc, argv, 700, 500, 200, 100, "Laborator EGC");
	//se apeleaza functia init() - in care s-au adaugat obiecte
	dw.init();
	//se intra in bucla principala de desenare - care face posibila desenarea, animatia si procesarea evenimentelor
	dw.run();
	return 0;

}