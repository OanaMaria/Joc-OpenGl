
    Elemente de grafica pe calculator - Tema1
        Geometry Wars
        Stefanescu Oana 332CB



		1. Cerinta

	Implementarea unui joc constand intr-o naveta controlata de utilizator care trebuie sa elimine toate navele inamice, primind un punctaj,
	fara a se lovi de ele. Daca in schimb acestea se lovesc jucatorul pierde o viata.	

		2. Utilizare
	
	Programul nu are parametrii de intrare.

	

	2.1 Input Tastatura

Taste :

    [UP]
		deplasarea inainte a navetei
	[DOWN]
		deplasarea inapoi a navetei
	[LEFT]
		rotirea catre dreapta a navetei
	[RIGHT]
		rotirea catre stanga a navetei
	[L]
        activarea armei
	[H]
		dezactivarea armei
	[BACKSPACE]
		lansare proiectil

	In partea de sus a ferestrei este afisat scorul si numarul de vieti ramase.


		3. Implementare

		
		Tema a fost realizata in C++ pe platforma Visual Studio 2012, Microsoft Windows 8.
		Scheletul de cod a fost cel din laboratorul 2.
		
		4. Testare

		Tema a fost testata in Visual Studio 2012. In cadrul testarii am verificat functionalitatile mentionate in cerinta.

		5. Probleme aparute

			Stergerea elementelor a fost o problema deoarece acestea au continuat sa existe, scorul crescand in continuare. 

		6. Continutul Arhivei

		main.cpp
			sursa principala a aplicatiei
		Enemy_2square.h, Enemy_arrow.h, Enemy_L.h, Enemy_square_romb.h
			fisiere header pentru cele 4 tipuri de inamici
		Ship.h
			fisier header pentru naveta
		Bullet.h
			fisier header pentru glont
		README
			acest fisier
		Si toate celelalte functii declarate in cadrul laboratorului 2.
		
		7. Functionalitati

    Functionalitati Standard (ca in enunt)
        Miscare naveta
        Afisare scor si vieti ramase
        Plasare nave inamice
        Coliziune dintre nava si inamici si dintre proiectil si inamici
    Functionalitati Bonus
        Lansare proiectil
    
